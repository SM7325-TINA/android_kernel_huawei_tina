

#ifndef HWQOS_COMMON_H
#define HWQOS_COMMON_H

#include <linux/types.h>
#include <chipset_common/hwqos/hwqos_sysctl.h>

#define QOS_TRANS_THREADS_NUM 24

struct task_struct;

void set_task_qos_by_tid(struct task_struct *task, int qos);
void set_task_qos_by_pid(struct task_struct *task, int qos);
int get_task_set_qos(struct task_struct *task);
int get_task_trans_qos(struct transact_qos *tq);
int get_task_qos(struct task_struct *task);
#ifdef CONFIG_HW_FUTEX_PI
int get_task_normal_qos(struct task_struct *task);
#endif
bool dynamic_qos_enqueue(struct task_struct *task,
	struct task_struct *from, unsigned int type);
void dynamic_qos_dequeue(struct task_struct *task, unsigned int type);
void iaware_proc_fork_inherit(struct task_struct *task,
	unsigned long clone_flags);
bool should_binder_do_set_priority(struct task_struct *task, int desired_prio, bool verify);
#endif
