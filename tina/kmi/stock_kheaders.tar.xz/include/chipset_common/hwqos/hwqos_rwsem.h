

#ifndef HWQOS_RWSEM_H
#define HWQOS_RWSEM_H

struct task_struct;

void rwsem_dynamic_qos_enqueue(struct task_struct *owner,
	struct task_struct *waiter_task);
void rwsem_dynamic_qos_dequeue(struct task_struct *task);
#endif
