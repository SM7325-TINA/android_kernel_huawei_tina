

#ifndef HWQOS_FORK_H
#define HWQOS_FORK_H

struct task_struct;

void init_task_qos_info(struct task_struct *p);
void release_task_qos_info(struct task_struct *p);
#endif
