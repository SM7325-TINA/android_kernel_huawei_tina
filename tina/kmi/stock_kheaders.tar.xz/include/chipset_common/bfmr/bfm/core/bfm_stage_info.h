

#ifndef BFM_TRACE_STAGETIME_H
#define BFM_TRACE_STAGETIME_H

#include "chipset_common/bfmr/public/bfmr_public.h"
#include "chipset_common/bfmr/common/bfmr_common.h"

#ifdef __cplusplus
extern "C" {
#endif

#define BMFR_MAX_BOOTUP_STAGE_COUNT 256
#define STAGE_INFO_RESERVED 32

struct bfm_stage_info {
	enum bfmr_detail_stage stage;
	unsigned int start_time; 
	char reserved[STAGE_INFO_RESERVED];
};

struct bfm_stages {
	unsigned int stage_count;
	struct bfm_stage_info stage_info_list[BMFR_MAX_BOOTUP_STAGE_COUNT];
};


void bfm_add_stage_info(struct bfm_stage_info *pstage);


size_t bfm_save_stages_info_txt(char *buffer, unsigned int buffer_len);


int bfm_init_stage_info(void);


void bfm_deinit_stage_info(void);

#ifdef __cplusplus
}
#endif

#endif

