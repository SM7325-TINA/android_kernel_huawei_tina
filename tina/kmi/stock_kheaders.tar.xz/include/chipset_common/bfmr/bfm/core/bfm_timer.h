

#ifndef BFM_TIMER_H
#define BFM_TIMER_H

#ifdef __cplusplus
extern "C" {
#endif

#define BFMR_ACTION_NAME_LEN 64

enum bfm_action_timer {
	ACT_TIMER_START = 0xbfac0000,
	ACT_TIMER_STOP = 0xbfac0001,
	ACT_TIMER_PAUSE = 0xbfac0002,
	ACT_TIMER_RESUME = 0xbfac0003,
};

struct action_ioctl_data {
	enum bfm_action_timer op;
	char action_name[BFMR_ACTION_NAME_LEN];
	u32 action_timer_timeout_value;
};


int bfm_get_boot_timer_state(int *state);


int bfm_suspend_boot_timer(void);


int bfmr_resume_boot_timer(void);


int bfm_set_boot_timer_timeout_value(unsigned int timeout_value);


int bfm_get_boot_timer_timeout_value(unsigned int *ptimeout_value);


int bfm_action_timer_start(char *act_name, unsigned int timeout_value);


int bfm_action_timer_stop(char *act_name);


int bfm_action_timer_pause(char *act_name);


int bfm_action_timer_resume(char *act_name);


int bfm_stop_boot_timer(void);


int bfm_init_boot_timer(void);

#ifdef __cplusplus
}
#endif

#endif

