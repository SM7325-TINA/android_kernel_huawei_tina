

#ifndef BFM_HISI_H
#define BFM_HISI_H

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif

