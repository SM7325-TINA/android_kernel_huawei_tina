

#ifndef BFR_CHIPSETS_H
#define BFR_CHIPSETS_H

#include <linux/types.h>
#include "chipset_common/bfmr/public/bfmr_public.h"

#ifdef __cplusplus
extern "C" {
#endif

bool bfr_bopd_has_been_enabled(void);
bool bfr_safe_mode_has_been_enabled(void);
int bfr_get_full_path_of_rrecord_part(char **path_buf);

#ifdef __cplusplus
}
#endif

#endif 


