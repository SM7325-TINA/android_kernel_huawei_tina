

void record_ptrace_info_before_return(long request, struct task_struct *child);
