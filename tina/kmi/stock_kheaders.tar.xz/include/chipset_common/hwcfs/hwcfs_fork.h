

#ifndef _HWCFS_FORK_H_
#define _HWCFS_FORK_H_

#include <linux/sched.h>

void init_task_vip_info(struct task_struct *task);
#endif
