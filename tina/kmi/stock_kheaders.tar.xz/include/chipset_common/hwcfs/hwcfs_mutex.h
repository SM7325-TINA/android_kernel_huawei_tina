

#ifndef _HWCFS_MUTEX_H_
#define _HWCFS_MUTEX_H_

#include <linux/sched.h>
#include <linux/mutex.h>

void mutex_list_add(struct task_struct *task, struct list_head *entry,
	struct list_head *head, struct mutex *lock);
void mutex_dynamic_vip_enqueue(struct mutex *lock, struct task_struct *task);
void mutex_dynamic_vip_dequeue(struct mutex *lock, struct task_struct *task);
#endif
