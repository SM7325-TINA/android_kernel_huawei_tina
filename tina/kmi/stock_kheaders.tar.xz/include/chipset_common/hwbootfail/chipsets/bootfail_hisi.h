

#ifndef BOOTFAIL_HISI_H
#define BOOTFAIL_HISI_H



#ifdef __cplusplus
extern "C" {
#endif




void set_valid_long_press_flag(void);


#ifdef __cplusplus
}
#endif
#endif
