

#ifndef ADAPTER_COMMON_H
#define ADAPTER_COMMON_H


#include <hwbootfail/core/adapter.h>
#include <linux/types.h>


#ifdef __cplusplus
extern "C" {
#endif




int common_adapter_init(struct adapter *padp);


#ifdef __cplusplus
}
#endif
#endif
