

#ifndef BOOTFAIL_CHIPSETS_H
#define BOOTFAIL_CHIPSETS_H


#include <linux/types.h>


#ifdef __cplusplus
extern "C" {
#endif




unsigned int get_bootup_time(void);
unsigned int get_long_timer_timeout_value(void);
unsigned int get_short_timer_timeout_value(void);
unsigned int get_action_timer_timeout_value(void);
char *get_bfi_dev_path(void);
size_t get_bfi_part_size(void);
long simulate_storge_rdonly(unsigned long arg);


#ifdef __cplusplus
}
#endif
#endif
