

#ifndef BOOTFAIL_HONGHU_H
#define BOOTFAIL_HONGHU_H


#include <hwbootfail/core/boot_detector.h>


#ifdef __cplusplus
extern "C" {
#endif




int process_bootfail(enum bootfail_errno bootfail_errno,
	enum suggest_recovery_method suggested_method,
	const char *detail_info);


#ifdef __cplusplus
}
#endif
#endif
