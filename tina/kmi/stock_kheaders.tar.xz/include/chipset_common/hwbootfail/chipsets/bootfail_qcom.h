

#ifndef BOOTFAIL_QCOM_H
#define BOOTFAIL_QCOM_H

#include <linux/vmalloc.h>
#include <linux/types.h>
#include <linux/semaphore.h>


#ifdef __cplusplus
extern "C" {
#endif




void set_valid_long_press_flag(void);
void save_long_press_info(void);
void bootfail_pwk_press(void);
void bootfail_pwk_release(void);


#ifdef __cplusplus
}
#endif
#endif
