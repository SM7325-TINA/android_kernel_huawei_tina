

#ifndef HW_XCOLLIE_H
#define HW_XCOLLIE_H


#define HW_INVALID_ID (-1)

#define HW_XCOLLIE_FLAG_DEFAULT   (~0)

#define HW_XCOLLIE_FLAG_NOOP      0

#define HW_XCOLLIE_FLAG_LOG       (1 << 0)

#define HW_XCOLLIE_FLAG_BACKTRACE (1 << 1)

#define HW_XCOLLIE_FLAG_RECOVERY  (1 << 2)

#define HW_MAX_TIMEOUT_VAL        60
#define HW_MIN_TIMEOUT_VAL        1

#define HW_MAX_XCOLLIE_SHIFT      7
#define HW_MAX_XCOLLIE_NUM        (1 << HW_MAX_XCOLLIE_SHIFT)

#ifdef CONFIG_HW_XCOLLIE
#define hw_xcollie_start(timeout, func, arg) \
__hw_xcollie_start_ex(__func__, timeout, func, arg, HW_XCOLLIE_FLAG_DEFAULT)

#define hw_xcollie_start_ex(timeout, func, arg, flag) \
__hw_xcollie_start_ex(__func__, timeout, func, arg, flag)

int __hw_xcollie_start_ex(const char *name,
			int timeout,
			int (*func)(void *),
			void *arg,
			int flag);
int hw_xcollie_update(int id, int timeout);
void hw_xcollie_end(int id);
#endif

#endif 
