

#ifndef _LINUX_LOGGER_H
#define _LINUX_LOGGER_H

#include <linux/fs.h>
#include <linux/ioctl.h>
#include <linux/types.h>


struct user_logger_entry_compat {
	__u16 len;
	__u16 __pad;
	__s32 pid;
	__s32 tid;
	__s32 sec;
	__s32 nsec;
	char msg[0];
};


struct logger_entry {
	__u16 len;
	__u16 hdr_size;
	__s32 pid;
	__s32 tid;
	__s32 sec;
	__s32 nsec;
	kuid_t euid;
	char msg[0];
};

struct hw_logger_msg {
	struct iovec *iov;
	unsigned long nr_segs;
};

extern struct huawei_log_tag __start_hwlog_tag, __stop_hwlog_tag;


#define LOGGER_LOG_EXCEPTION		"hwlog_exception"

#define LOGGER_LOG_JANK			"hwlog_jank"

#define LOGGER_LOG_DUBAI		"hwlog_dubai"

#define LOGGER_ENTRY_MAX_PAYLOAD	4076

#define __LOGGERIO	0xAE
#define CHECK_CODE	0x7BCDABCD

enum CheckError {
	EVecSeg = 1,
	EVecLen,
	EVecCopy,
	EVecCode,
};


#define O_HWLOGGER_RDDEL		01000000000

#define LOGGER_GET_LOG_BUF_SIZE		_IO(__LOGGERIO, 1)

#define LOGGER_GET_LOG_LEN		_IO(__LOGGERIO, 2)

#define LOGGER_GET_NEXT_ENTRY_LEN	_IO(__LOGGERIO, 3)

#define LOGGER_FLUSH_LOG		_IO(__LOGGERIO, 4)

#define LOGGER_SET_RDDEL		_IO(__LOGGERIO, 5)

#define LOGGER_RESET_RDDEL		_IO(__LOGGERIO, 6)

#endif 
