

#ifndef HWMANUFAC_RUNMODE_TYPE_H
#define HWMANUFAC_RUNMODE_TYPE_H
unsigned int get_runmode_type(void);

#endif
