

#ifndef _HALL_INTERFACE_H_
#define _HALL_INTERFACE_H_

struct hall_interface_ops {
	void *dev_data;
	bool (*get_hall_status)(void);
};

struct hall_interface_dev {
	struct hall_interface_ops *p_ops;
};

#ifdef CONFIG_HUAWEI_HALL_INTERFACE
int hall_interface_ops_register(struct hall_interface_ops *ops);
bool hall_interface_get_hall_status(void);
#else
static inline int hall_interface_ops_register(struct hall_interface_ops *ops)
{
	return -1;
}

static inline bool hall_interface_get_hall_status(void)
{
	return false;
}
#endif 

#endif 
